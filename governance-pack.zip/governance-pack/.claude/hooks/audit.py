#!/usr/bin/env python3
"""
PostToolUse audit hook — appends one JSON line per executed action to
~/.claude/autonomy-audit.log. Read it with:  tail -f ~/.claude/autonomy-audit.log
Never blocks anything; exists purely for the paper trail.
"""
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

LOG = Path.home() / ".claude" / "autonomy-audit.log"

def main() -> None:
    try:
        payload = json.load(sys.stdin)
    except Exception:
        sys.exit(0)

    entry = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "event": "executed",
        "session": payload.get("session_id", ""),
        "tool": payload.get("tool_name", ""),
        "input": str(payload.get("tool_input", ""))[:500],
        "ok": not bool((payload.get("tool_response") or {}).get("is_error")
                       if isinstance(payload.get("tool_response"), dict) else False),
    }
    try:
        LOG.parent.mkdir(parents=True, exist_ok=True)
        with LOG.open("a") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        pass
    sys.exit(0)

if __name__ == "__main__":
    main()
