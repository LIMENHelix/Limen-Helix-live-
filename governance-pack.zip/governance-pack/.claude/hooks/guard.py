#!/usr/bin/env python3
"""
PreToolUse guard hook — enforces Chris's red lines deterministically.

Red lines:
  1. MONEY MOVEMENT  — no refunds, charges, payouts, transfers, purchases.
  2. DATA DELETION   — no destructive deletes outside the scratch workspace.

Exit codes (Claude Code hook contract):
  0 = allow
  2 = BLOCK; stderr is fed back to the model as the reason.
"""
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

LOG = Path.home() / ".claude" / "autonomy-audit.log"

# Paths the agent may freely delete within (its own scratch space).
SAFE_DELETE_PREFIXES = (
    "/tmp/", "/var/tmp/",
    str(Path.home()) + "/workspace/", str(Path.home()) + "/scratch/",
    "node_modules", "dist/", "build/", ".cache", "__pycache__",
)

# ---- Red line 1: money movement ---------------------------------------
MONEY_PATTERNS = [
    r"\bstripe\b.*\b(refund|charge|payout|transfer|payment[_-]?intent.*(confirm|capture)|subscription.*(create|update|cancel))",
    r"api\.stripe\.com/v\d+/(refunds|charges|payouts|transfers|payment_intents|subscription)",
    r"\b(paypal|venmo|wise|plaid|square(up)?)\b.*\b(pay|refund|transfer|charge|payout)",
    r"\bbraintree\b.*\b(transaction|refund)",
]

# ---- Red line 2: destructive deletion ----------------------------------
DELETE_PATTERNS = [
    r"\brm\s+(-[a-zA-Z]*\s+)*(/|~|\$HOME|\.\.)",          # rm on rooty/home/parent paths
    r"\brm\s+-[a-zA-Z]*[rf][a-zA-Z]*\b",                   # any rm -r / rm -f (checked vs safe list below)
    r"\b(shred|wipefs|mkfs\w*|blkdiscard)\b",
    r"\bdd\b.*\bof=/dev/",
    r"\bgit\s+push\b.*(--force\b|--force-with-lease|\s\+\S+|--delete|\s:\S+)",
    r"\bgit\s+branch\s+(-[a-zA-Z]*D|-[a-zA-Z]*d\b.*--force)",
    r"\bgit\s+reset\s+--hard\b.*(origin|upstream)",
    r"\bgit\s+clean\s+-[a-zA-Z]*f",
    r"\bDROP\s+(TABLE|DATABASE|SCHEMA|INDEX)\b",
    r"\bTRUNCATE\s+TABLE\b",
    r"\bDELETE\s+FROM\b(?!.*\bWHERE\b)",
    r"\b(aws\s+s3\s+(rm|rb)|aws\s+\S+\s+delete-|gcloud\s+\S+\s+delete|az\s+\S+\s+delete)\b",
    r"\bvercel\s+(remove|rm)\b",
    r"\bgh\s+(repo|release)\s+delete\b",
    r"\bfind\b.*-delete\b",
    r"\bcrontab\s+-r\b",
]

# Tools whose very invocation is a red line (MCP money/deletion tools).
BLOCKED_TOOL_NAMES = re.compile(
    r"(create_refund|create_charge|create_payout|create_transfer|"
    r"delete_event|delete_file|delete_project|delete_page|stripe_api_write)",
    re.IGNORECASE,
)


def log(entry: dict) -> None:
    try:
        LOG.parent.mkdir(parents=True, exist_ok=True)
        entry["ts"] = datetime.now(timezone.utc).isoformat()
        with LOG.open("a") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        pass  # auditing must never break the run


def block(reason: str, payload: dict) -> None:
    log({"event": "BLOCKED", "reason": reason,
         "tool": payload.get("tool_name"),
         "input": str(payload.get("tool_input"))[:500]})
    print(f"BLOCKED by governance hook: {reason}. "
          f"This is a hard red line. Do not attempt a workaround — "
          f"summarize what you wanted to do and escalate to Chris.",
          file=sys.stderr)
    sys.exit(2)


def deletion_is_safe(command: str) -> bool:
    """rm is tolerated only when every target sits in known scratch space."""
    tokens = [t for t in re.split(r"\s+", command) if t]
    try:
        idx = next(i for i, t in enumerate(tokens) if t == "rm" or t.endswith("/rm"))
    except StopIteration:
        return False
    targets = [t for t in tokens[idx + 1:] if not t.startswith("-")]
    if not targets:
        return False
    return all(any(p in t for p in SAFE_DELETE_PREFIXES) for t in targets)


def main() -> None:
    try:
        payload = json.load(sys.stdin)
    except Exception:
        sys.exit(0)  # malformed input: fail open for non-parseable events

    tool = payload.get("tool_name", "")
    tool_input = payload.get("tool_input", {}) or {}

    # Block red-line MCP tools outright.
    if BLOCKED_TOOL_NAMES.search(tool):
        block(f"tool '{tool}' moves money or deletes data", payload)

    if tool == "Bash":
        cmd = tool_input.get("command", "")
        for pat in MONEY_PATTERNS:
            if re.search(pat, cmd, re.IGNORECASE):
                block("money-movement command pattern", payload)
        for pat in DELETE_PATTERNS:
            if re.search(pat, cmd, re.IGNORECASE):
                if pat.startswith(r"\brm") and deletion_is_safe(cmd):
                    continue  # rm confined to scratch space is fine
                block("destructive-deletion command pattern", payload)

    log({"event": "allowed", "tool": tool,
         "summary": str(tool_input)[:200]})
    sys.exit(0)


if __name__ == "__main__":
    main()
