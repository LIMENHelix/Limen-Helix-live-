# Governance Pack — Safeguards for Autonomous Claude Runs

Configured for: Chris Hubbel · July 2026
Posture: **Draft-first** autonomy · Red lines: **money movement** and **data deletion** · Notifications: **exceptions only**

## What's in here

```
governance-pack/
├── CLAUDE.md                  # The constitution — judgment-layer rules every run loads
├── settings.template.json     # Claude Code permissions + hook registration
├── .claude/
│   └── hooks/
│       ├── guard.py           # PreToolUse blocker (red lines, deterministic)
│       └── audit.py           # PostToolUse logger (paper trail)
└── README.md
```

## The three layers

1. **CLAUDE.md (judgment)** — tells the model the rules: act freely on safe work,
   stop at draft for anything outward-facing, never touch money or delete data,
   escalate instead of improvising, do it yourself instead of recommending SaaS.
2. **guard.py (enforcement)** — runs before *every* tool call. Blocks money-movement
   and destructive-deletion patterns even if the model tries them. Tested against
   24 cases (Stripe CLI/API, force-pushes, DROP TABLE, `aws s3 rm`, `vercel remove`,
   `rm -rf` outside scratch space, blocked MCP tools) — deletes confined to
   /tmp, node_modules, build dirs etc. still work so builds don't break.
3. **audit.py (accountability)** — every executed action appended as a JSON line to
   `~/.claude/autonomy-audit.log`. Review with `tail -f` or ask Claude to summarize it.

## Install into any project

```bash
cp -r governance-pack/.claude  /path/to/project/
cp governance-pack/CLAUDE.md   /path/to/project/CLAUDE.md   # or merge into existing
cp governance-pack/settings.template.json /path/to/project/.claude/settings.json
chmod +x /path/to/project/.claude/hooks/*.py
```

The rename of `settings.template.json` → `.claude/settings.json` is deliberate:
tools treat live settings files as sensitive (correctly), so the pack ships it
as a template.

## Verify it's active

From inside the project, ask Claude Code to run `stripe refunds create --charge test`.
It should refuse with "BLOCKED by governance hook" — and the attempt will appear
in the audit log with `"event": "BLOCKED"`.

## Extending

- New red line → add a regex to `MONEY_PATTERNS` / `DELETE_PATTERNS` in guard.py,
  or a tool name to `BLOCKED_TOOL_NAMES`, add a test case, rerun the suite.
- New always-deny command → add to `permissions.deny` in settings.json.
- Loosening the leash → edit the draft-first list in CLAUDE.md; the red lines
  in guard.py stay regardless.

## Escalation contract

A blocked or out-of-scope situation ends the run with a summary of the decision
needed. Nothing retries, nothing works around. The absence of a rule is not
permission.
