---
name: ai-video
description: Create AI videos three ways — free programmatic motion-graphics videos (promos, explainers, product demos) rendered locally with no API; generative text-to-video clips via fal.ai (Kling/Veo/Luma); and talking-head avatar videos via HeyGen. Use when the user asks to make a video, promo, explainer, video ad, animated announcement, text-to-video clip, or avatar/talking-head video.
---

# AI Video Creation

Three pipelines, cheapest-first. ALWAYS prefer the free programmatic pipeline
unless the user explicitly needs photorealistic generated footage or a human
presenter.

## Decision guide

| User wants | Pipeline | Cost |
|---|---|---|
| Promo, explainer, announcement, product demo, social clip with text/graphics | `render_programmatic.py` | $0 |
| Photoreal/cinematic footage from a text prompt | `generate_clip.py` (fal.ai) | ~$0.04–0.15 per second |
| A presenter speaking a script | `avatar_video.py` (HeyGen) | ~$0.30–1.00 per minute |

Mixed videos: generate clips, then stitch with the programmatic renderer's
scenes using ffmpeg concat.

## 1. Programmatic (free, always works)

Write a scene-spec JSON (see `specs/demo.json` for a working example, and the
docstring in `scripts/render_programmatic.py` for the format), then:

    python3 scripts/render_programmatic.py spec.json output.mp4

Scene types: `title`, `bullets`, `stat`, `endcard`. Brand colors are set in
the spec. Voiceover uses espeak-ng offline (set `"voice": "none"` to disable;
if edge-tts is reachable in the environment, prefer it for natural voices).
A soft synthesized music bed is generated automatically (`"music": false` to
disable). Render time ≈ 2x video duration.

Iterate: render, extract frames (`ffmpeg -i out.mp4 -vf "select=..." f_%d.png`),
LOOK at them, adjust the spec, re-render. Never ship a video you haven't
visually checked.

## 2. Generative clips (needs FAL_KEY)

    export FAL_KEY=...   # from fal.ai/dashboard/keys
    python3 scripts/generate_clip.py "prompt" out.mp4 --model kling --seconds 5

Models: `luma` (cheapest), `kling` (default, best balance), `veo` (best
quality, native audio). A COST GUARD refuses runs above `--max-cost`
(default $0.50); raise it explicitly per run, never edit the default.

## 3. Avatar videos (needs HEYGEN_API_KEY)

    export HEYGEN_API_KEY=...
    python3 scripts/avatar_video.py --list-avatars     # once, to pick
    python3 scripts/avatar_video.py "Script..." out.mp4 --avatar-id X --voice-id Y

Same cost-guard pattern (default $2.00 ceiling).

## Governance rules (non-negotiable)

- API keys come from environment variables only. Never write a key into a
  file, commit, or log.
- Cost guards are rails, not suggestions: raise ceilings per-run with an
  explicit flag when the task justifies it. If a run is blocked by a guard,
  report the estimate and ask — do not loop with higher values.
- These APIs spend real money per call. In autonomous/scheduled runs, batch
  prompts and get the total estimated cost approved in the trigger's rules
  before generating.
- Deliver every finished video to the user; delete intermediates.
