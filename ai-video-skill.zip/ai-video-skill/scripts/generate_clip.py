#!/usr/bin/env python3
"""
Generative AI video clips via fal.ai (one key, many models).

Setup:  export FAL_KEY=...        (get one at fal.ai/dashboard/keys)
Usage:  python3 generate_clip.py "a drone shot over a neon city at dusk" out.mp4 \
            [--model kling] [--seconds 5] [--max-cost 1.00]

Models (July 2026 pricing, approximate — verify on fal.ai):
  luma    Luma Ray 2          ~$0.04/s   cheapest, good motion
  kling   Kling 3.0           ~$0.075/s  best price/quality balance  (default)
  veo     Veo 3.1 Fast        ~$0.15/s   best quality + native audio

COST GUARD: refuses to run if estimated cost exceeds --max-cost (default $0.50).
This is a governance rail: raise it deliberately per run, never permanently.
"""
import argparse
import json
import os
import sys
import time
import urllib.request

MODELS = {
    "luma":  {"endpoint": "fal-ai/luma-dream-machine/ray-2",  "usd_per_sec": 0.04},
    "kling": {"endpoint": "fal-ai/kling-video/v3/standard/text-to-video", "usd_per_sec": 0.075},
    "veo":   {"endpoint": "fal-ai/veo3/fast", "usd_per_sec": 0.15},
}


def api(url, key, payload=None):
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode() if payload is not None else None,
        headers={"Authorization": f"Key {key}", "Content-Type": "application/json"},
        method="POST" if payload is not None else "GET")
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("prompt")
    ap.add_argument("output")
    ap.add_argument("--model", default="kling", choices=list(MODELS))
    ap.add_argument("--seconds", type=int, default=5)
    ap.add_argument("--max-cost", type=float, default=0.50,
                    help="hard ceiling in USD for this run")
    args = ap.parse_args()

    key = os.environ.get("FAL_KEY")
    if not key:
        sys.exit("FAL_KEY not set. Get a key at https://fal.ai/dashboard/keys "
                 "and export FAL_KEY=... — never hardcode it.")

    m = MODELS[args.model]
    est = m["usd_per_sec"] * args.seconds
    if est > args.max_cost:
        sys.exit(f"COST GUARD: estimated ${est:.2f} for {args.seconds}s of "
                 f"{args.model} exceeds --max-cost ${args.max_cost:.2f}. "
                 f"Re-run with an explicit higher --max-cost if intended.")
    print(f"Estimated cost: ${est:.2f} ({args.model}, {args.seconds}s) — within guard.")

    # Submit to fal queue
    submit = api(f"https://queue.fal.run/{m['endpoint']}", key, {
        "prompt": args.prompt,
        "duration": args.seconds,
    })
    status_url = submit.get("status_url")
    response_url = submit.get("response_url")
    if not status_url:
        sys.exit(f"unexpected submit response: {submit}")

    print("Generating", end="", flush=True)
    for _ in range(180):  # up to ~15 min
        time.sleep(5)
        st = api(status_url, key)
        s = st.get("status")
        print(".", end="", flush=True)
        if s == "COMPLETED":
            break
        if s in ("FAILED", "ERROR"):
            sys.exit(f"\ngeneration failed: {st}")
    else:
        sys.exit("\ntimed out waiting for generation")

    result = api(response_url, key)
    video_url = (result.get("video") or {}).get("url") or result.get("video_url")
    if not video_url:
        sys.exit(f"\nno video url in result: {result}")
    urllib.request.urlretrieve(video_url, args.output)
    print(f"\nOK {args.output} ({os.path.getsize(args.output)//1024} KB, "
          f"~${est:.2f} spent)")


if __name__ == "__main__":
    main()
