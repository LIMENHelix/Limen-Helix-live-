#!/usr/bin/env python3
"""
Programmatic AI video renderer — no external APIs, no per-clip cost.

Takes a JSON "scene spec" and renders an MP4 with animated motion graphics,
optional AI voiceover, and a synthesized ambient music bed.

Usage:
    python3 render_programmatic.py spec.json output.mp4

Scene spec format (JSON):
{
  "width": 1280, "height": 720, "fps": 30,
  "brand": {"bg_top": "#0f1226", "bg_bottom": "#1c2451",
            "accent": "#5b8cff", "text": "#f4f6ff", "muted": "#9aa5d1"},
  "voice": "en-US+m3",          // espeak-ng voice, or "none"
  "music": true,                 // synthesized ambient pad under everything
  "scenes": [
    {"type": "title",   "seconds": 3.5, "title": "LIMEN Helix",
     "subtitle": "Autonomy, governed.", "narration": "optional spoken line"},
    {"type": "bullets", "seconds": 5, "heading": "What it does",
     "items": ["Point one", "Point two", "Point three"], "narration": "..."},
    {"type": "stat",    "seconds": 3, "value": "24/7", "label": "always on",
     "narration": "..."},
    {"type": "endcard", "seconds": 3, "title": "limenhelix.com",
     "subtitle": "Get started today", "narration": "..."}
  ]
}
"""
import json
import math
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import wave

from PIL import Image, ImageDraw, ImageFilter, ImageFont

# ----------------------------------------------------------------------
# Font discovery — works on stock Linux containers
# Cross-platform (Windows / macOS / Linux). load_default() is a FIXED tiny bitmap
# that ignores size, so a real TrueType file MUST be found or all text renders tiny.
FONT_BOLD = [
    "C:/Windows/Fonts/arialbd.ttf", "C:/Windows/Fonts/segoeuib.ttf", "C:/Windows/Fonts/calibrib.ttf",
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf", "/Library/Fonts/Arial Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
]
FONT_REG = [
    "C:/Windows/Fonts/arial.ttf", "C:/Windows/Fonts/segoeui.ttf", "C:/Windows/Fonts/calibri.ttf",
    "/System/Library/Fonts/Supplemental/Arial.ttf", "/Library/Fonts/Arial.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
]

def font(size, bold=True):
    for path in (FONT_BOLD if bold else FONT_REG) + (FONT_REG if bold else FONT_BOLD):
        if os.path.exists(path):
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                continue
    return ImageFont.load_default()


def fit_font(draw, text, max_width, start_px, bold=True, min_px=18):
    """Largest font size (<= start_px) whose rendered text fits within max_width."""
    size = start_px
    while size > min_px:
        f = font(size, bold=bold)
        if draw.textlength(text, font=f) <= max_width:
            return f
        size = int(size * 0.92)
    return font(min_px, bold=bold)


def hex_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def ease(t):
    """Smooth ease-in-out, t in [0,1]."""
    return 0.5 - 0.5 * math.cos(math.pi * max(0.0, min(1.0, t)))


# ----------------------------------------------------------------------
class Renderer:
    def __init__(self, spec):
        self.w = spec.get("width", 1280)
        self.h = spec.get("height", 720)
        self.fps = spec.get("fps", 30)
        b = spec.get("brand", {})
        self.bg_top = hex_rgb(b.get("bg_top", "#0f1226"))
        self.bg_bottom = hex_rgb(b.get("bg_bottom", "#1c2451"))
        self.accent = hex_rgb(b.get("accent", "#5b8cff"))
        self.text = hex_rgb(b.get("text", "#f4f6ff"))
        self.muted = hex_rgb(b.get("muted", "#9aa5d1"))
        self._bg_cache = None

    # -- background with slow drifting glow orbs ------------------------
    def background(self, t_global):
        if self._bg_cache is None:
            base = Image.new("RGB", (self.w, self.h))
            px = base.load()
            for y in range(self.h):
                f = y / self.h
                px_row = tuple(
                    int(self.bg_top[i] + (self.bg_bottom[i] - self.bg_top[i]) * f)
                    for i in range(3))
                for x in range(self.w):
                    px[x, y] = px_row
            self._bg_cache = base
        img = self._bg_cache.copy()
        glow = Image.new("RGB", (self.w, self.h), (0, 0, 0))
        gd = ImageDraw.Draw(glow)
        for i, speed in enumerate((0.11, 0.07, 0.05)):
            cx = self.w * (0.25 + 0.5 * (0.5 + 0.5 * math.sin(t_global * speed + i * 2.1)))
            cy = self.h * (0.3 + 0.4 * (0.5 + 0.5 * math.cos(t_global * speed * 1.3 + i)))
            r = int(min(self.w, self.h) * 0.28)
            col = tuple(int(c * 0.35) for c in self.accent)
            gd.ellipse([cx - r, cy - r, cx + r, cy + r], fill=col)
        glow = glow.filter(ImageFilter.GaussianBlur(90))
        return Image.blend(img, Image.blend(img, glow, 0.5), 0.9)

    def _center_text(self, draw, txt, fnt, y, fill, alpha_img=None, dx=0):
        bbox = draw.textbbox((0, 0), txt, font=fnt)
        x = (self.w - (bbox[2] - bbox[0])) / 2 + dx
        draw.text((x, y), txt, font=fnt, fill=fill)

    def _fade(self, img, scene_t, seconds):
        """Fade scene in/out over 0.4s edges."""
        edge = 0.4
        a = 1.0
        if scene_t < edge:
            a = scene_t / edge
        elif scene_t > seconds - edge:
            a = max(0.0, (seconds - scene_t) / edge)
        if a >= 0.999:
            return img
        black = Image.new("RGB", img.size, (5, 6, 16))
        return Image.blend(black, img, a)

    # -- scene renderers -------------------------------------------------
    def scene_title(self, s, scene_t, t_global):
        img = self.background(t_global)
        d = ImageDraw.Draw(img)
        p = ease(scene_t / 1.0)
        big = fit_font(d, s["title"], self.w * 0.88, int(self.h * 0.13))
        sub = font(int(self.h * 0.045), bold=False)
        rise = int((1 - p) * 40)
        col = tuple(int(c * p) for c in self.text)
        self._center_text(d, s["title"], big, self.h * 0.38 + rise, col)
        if s.get("subtitle"):
            p2 = ease((scene_t - 0.5) / 1.0)
            col2 = tuple(int(c * p2) for c in self.muted)
            self._center_text(d, s["subtitle"], sub, self.h * 0.56 + rise // 2, col2)
        bw = int(self.w * 0.22 * ease(scene_t / 1.4))
        d.rectangle([(self.w - bw) / 2, self.h * 0.52,
                     (self.w + bw) / 2, self.h * 0.525], fill=self.accent)
        return self._fade(img, scene_t, s["seconds"])

    def scene_bullets(self, s, scene_t, t_global):
        img = self.background(t_global)
        d = ImageDraw.Draw(img)
        head = font(int(self.h * 0.07))
        item_f = font(int(self.h * 0.045), bold=False)
        p = ease(scene_t / 0.8)
        d.text((self.w * 0.1, self.h * 0.16), s["heading"], font=head,
               fill=tuple(int(c * p) for c in self.text))
        d.rectangle([self.w * 0.1, self.h * 0.27,
                     self.w * 0.1 + int(self.w * 0.12 * p), self.h * 0.275],
                    fill=self.accent)
        items = s.get("items", [])
        for i, item in enumerate(items):
            ip = ease((scene_t - 0.5 - i * 0.45) / 0.7)
            if ip <= 0:
                continue
            y = self.h * (0.38 + 0.11 * i)
            slide = int((1 - ip) * 60)
            r = int(self.h * 0.011)
            cy = y + self.h * 0.028
            d.ellipse([self.w * 0.12 + slide - r, cy - r,
                       self.w * 0.12 + slide + r, cy + r],
                      fill=tuple(int(c * ip) for c in self.accent))
            d.text((self.w * 0.145 + slide, y), item, font=item_f,
                   fill=tuple(int(c * ip) for c in self.text))
        return self._fade(img, scene_t, s["seconds"])

    def scene_stat(self, s, scene_t, t_global):
        img = self.background(t_global)
        d = ImageDraw.Draw(img)
        p = ease(scene_t / 0.9)
        big = font(int(self.h * 0.22))
        lab = font(int(self.h * 0.05), bold=False)
        scale_col = tuple(int(c * p) for c in self.accent)
        self._center_text(d, s["value"], big, self.h * 0.30, scale_col)
        p2 = ease((scene_t - 0.4) / 0.8)
        self._center_text(d, s["label"], lab, self.h * 0.60,
                          tuple(int(c * p2) for c in self.muted))
        return self._fade(img, scene_t, s["seconds"])

    def scene_endcard(self, s, scene_t, t_global):
        img = self.background(t_global)
        d = ImageDraw.Draw(img)
        p = ease(scene_t / 1.0)
        big = fit_font(d, s["title"], self.w * 0.72, int(self.h * 0.085))
        sub = font(int(self.h * 0.042), bold=False)
        # rounded pill behind the title
        tw = d.textbbox((0, 0), s["title"], font=big)
        pad = int(self.h * 0.045)
        x0 = (self.w - (tw[2] - tw[0])) / 2 - pad * 1.6
        y0 = self.h * 0.40 - pad
        x1 = (self.w + (tw[2] - tw[0])) / 2 + pad * 1.6
        y1 = self.h * 0.40 + (tw[3] - tw[1]) + pad * 1.4
        d.rounded_rectangle([x0, y0, x1, y1], radius=int(pad * 1.2),
                            outline=tuple(int(c * p) for c in self.accent),
                            width=max(2, int(self.h * 0.006)))
        self._center_text(d, s["title"], big, self.h * 0.40,
                          tuple(int(c * p) for c in self.text))
        p2 = ease((scene_t - 0.5) / 1.0)
        self._center_text(d, s.get("subtitle", ""), sub, self.h * 0.60,
                          tuple(int(c * p2) for c in self.muted))
        return self._fade(img, scene_t, s["seconds"])

    def render_frame(self, scene, scene_t, t_global):
        fn = getattr(self, f"scene_{scene['type']}", None)
        if fn is None:
            raise ValueError(f"unknown scene type: {scene['type']}")
        return fn(scene, scene_t, t_global)


# ----------------------------------------------------------------------
def synth_music(path, seconds, sr=44100):
    """Soft ambient pad: slow-attack chord, no numpy needed."""
    freqs = [110.0, 164.81, 220.0, 329.63]  # A2 E3 A3 E4
    n = int(seconds * sr)
    frames = bytearray()
    for i in range(n):
        t = i / sr
        env = min(1.0, t / 3.0) * min(1.0, (seconds - t) / 2.0)
        v = sum(math.sin(2 * math.pi * f * t + k) *
                (0.55 ** k) for k, f in enumerate(freqs))
        wobble = 0.85 + 0.15 * math.sin(2 * math.pi * 0.08 * t)
        sample = int(max(-1, min(1, v * 0.06 * env * wobble)) * 32767)
        frames += struct.pack("<h", sample)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(bytes(frames))


def _mix_scene_clips(clips, out_wav, total_seconds):
    """Shared: place each (offset, audiofile) at its scene start and mix to out_wav."""
    if not clips:
        return False
    inputs, filters, amix = [], [], []
    for i, (offset, af) in enumerate(clips):
        inputs += ["-i", af]
        filters.append(
            f"[{i}]adelay={int(offset*1000)}|{int(offset*1000)},"
            f"apad=whole_dur={total_seconds}[a{i}]")
        amix.append(f"[a{i}]")
    fc = ";".join(filters) + ";" + "".join(amix) + \
        f"amix=inputs={len(clips)}:normalize=0[out]"
    subprocess.run(["ffmpeg", "-y", *inputs, "-filter_complex", fc,
                    "-map", "[out]", "-ar", "44100", out_wav],
                   check=True, capture_output=True)
    return True


def _edge_cmd():
    """edge-tts invocation that works whether or not the CLI is on PATH."""
    if shutil.which("edge-tts"):
        return ["edge-tts"]
    try:
        import edge_tts  # noqa: F401
        return [sys.executable, "-m", "edge_tts"]
    except Exception:
        return None


def make_voiceover_edge(narrations, voice, out_wav, total_seconds, scene_offsets):
    """edge-tts natural neural voices (free, needs internet). `voice` e.g. en-US-GuyNeural.
    Returns False if edge-tts is not installed or any synth fails (caller falls back)."""
    base = _edge_cmd()
    if not base:
        return False
    clips = []
    with tempfile.TemporaryDirectory() as td:
        for idx, (offset, text) in enumerate(zip(scene_offsets, narrations)):
            if not text:
                continue
            mp3 = os.path.join(td, f"n{idx}.mp3")
            try:
                subprocess.run(base + ["--voice", voice, "--text", text,
                                       "--write-media", mp3], check=True, capture_output=True)
            except Exception:
                return False
            if not os.path.exists(mp3) or os.path.getsize(mp3) == 0:
                return False
            clips.append((offset, mp3))
        return _mix_scene_clips(clips, out_wav, total_seconds)


def make_voiceover(narrations, voice, out_wav, total_seconds, scene_offsets):
    """espeak-ng per scene, placed at each scene's start with ffmpeg."""
    if not shutil.which("espeak-ng"):
        return False
    clips = []
    with tempfile.TemporaryDirectory() as td:
        for idx, (offset, text) in enumerate(zip(scene_offsets, narrations)):
            if not text:
                continue
            wav = os.path.join(td, f"n{idx}.wav")
            subprocess.run(["espeak-ng", "-v", voice, "-s", "150", "-p", "40",
                            "-w", wav, text], check=True, capture_output=True)
            clips.append((offset, wav))
        if not clips:
            return False
        inputs, filters, amix = [], [], []
        for i, (offset, wav) in enumerate(clips):
            inputs += ["-i", wav]
            filters.append(
                f"[{i}]adelay={int(offset*1000)}|{int(offset*1000)},"
                f"apad=whole_dur={total_seconds}[a{i}]")
            amix.append(f"[a{i}]")
        fc = ";".join(filters) + ";" + "".join(amix) + \
            f"amix=inputs={len(clips)}:normalize=0[out]"
        subprocess.run(["ffmpeg", "-y", *inputs, "-filter_complex", fc,
                        "-map", "[out]", "-ar", "44100", out_wav],
                       check=True, capture_output=True)
    return True


def main():
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(1)
    spec = json.load(open(sys.argv[1]))
    out = sys.argv[2]
    r = Renderer(spec)
    scenes = spec["scenes"]
    total = sum(s["seconds"] for s in scenes)

    workdir = tempfile.mkdtemp(prefix="vid_")
    video_only = os.path.join(workdir, "video.mp4")

    # Stream frames straight into ffmpeg (no giant frame dumps on disk)
    ff = subprocess.Popen(
        ["ffmpeg", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24",
         "-s", f"{r.w}x{r.h}", "-r", str(r.fps), "-i", "-",
         "-c:v", "libx264", "-preset", "medium", "-crf", "20",
         "-pix_fmt", "yuv420p", video_only],
        stdin=subprocess.PIPE, stderr=subprocess.DEVNULL)

    t_global = 0.0
    frame_dt = 1.0 / r.fps
    for scene in scenes:
        n_frames = int(scene["seconds"] * r.fps)
        for f in range(n_frames):
            scene_t = f * frame_dt
            img = r.render_frame(scene, scene_t, t_global)
            ff.stdin.write(img.tobytes())
            t_global += frame_dt
    ff.stdin.close()
    ff.wait()
    if ff.returncode != 0:
        sys.exit("ffmpeg video encode failed")

    # ---- audio ----
    audio_inputs = []
    offsets, narrs, acc = [], [], 0.0
    for s in scenes:
        offsets.append(acc + 0.35)
        narrs.append(s.get("narration", ""))
        acc += s["seconds"]

    vo_wav = os.path.join(workdir, "vo.wav")
    voice = spec.get("voice", "en-US+m3")
    # Engine: "edge" (natural neural, needs `pip install edge-tts` + internet) when the voice
    # looks like a neural voice or tts=="edge"; else espeak-ng. Edge falls back to espeak.
    tts = spec.get("tts")
    use_edge = (tts == "edge") or (tts is None and "Neural" in voice)
    if voice == "none":
        has_vo = False
    elif use_edge:
        has_vo = make_voiceover_edge(narrs, voice, vo_wav, total, offsets)
        if not has_vo:
            has_vo = make_voiceover(narrs, spec.get("espeak_voice", "en-US+m3"), vo_wav, total, offsets)
    else:
        has_vo = make_voiceover(narrs, voice, vo_wav, total, offsets)

    music_wav = os.path.join(workdir, "music.wav")
    has_music = bool(spec.get("music", True))
    if has_music:
        synth_music(music_wav, total)

    if has_vo and has_music:
        cmd = ["ffmpeg", "-y", "-i", video_only, "-i", music_wav, "-i", vo_wav,
               "-filter_complex",
               "[1]volume=0.5[m];[2]volume=1.6[v];[m][v]amix=inputs=2:normalize=0[a]",
               "-map", "0:v", "-map", "[a]", "-c:v", "copy",
               "-c:a", "aac", "-shortest", out]
    elif has_music or has_vo:
        src = music_wav if has_music else vo_wav
        cmd = ["ffmpeg", "-y", "-i", video_only, "-i", src,
               "-map", "0:v", "-map", "1:a", "-c:v", "copy",
               "-c:a", "aac", "-shortest", out]
    else:
        cmd = ["ffmpeg", "-y", "-i", video_only, "-c", "copy", out]
    subprocess.run(cmd, check=True, capture_output=True)
    shutil.rmtree(workdir, ignore_errors=True)
    dur = f"{total:.1f}s"
    size = os.path.getsize(out) // 1024
    print(f"OK {out} ({dur}, {size} KB, {r.w}x{r.h}@{r.fps}fps, "
          f"voiceover={'yes' if has_vo else 'no'}, music={'yes' if has_music else 'no'})")


if __name__ == "__main__":
    main()
