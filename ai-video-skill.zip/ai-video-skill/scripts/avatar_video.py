#!/usr/bin/env python3
"""
Talking-head avatar videos via HeyGen API v2.

Setup:  export HEYGEN_API_KEY=...   (heygen.com -> Settings -> API)
Usage:  python3 avatar_video.py "Script text the avatar will speak" out.mp4 \
            [--avatar-id AVATAR_ID] [--voice-id VOICE_ID] [--max-cost 2.00]

List available avatars/voices first:
    python3 avatar_video.py --list-avatars
    python3 avatar_video.py --list-voices

COST GUARD: HeyGen bills in credits (~$0.30-1.00 per video minute depending
on plan). The guard estimates 150 words/min speech and refuses runs whose
estimated minutes exceed --max-cost at $1/min unless raised explicitly.
"""
import argparse
import json
import os
import sys
import time
import urllib.request

BASE = "https://api.heygen.com"


def api(path, key, payload=None, method=None):
    req = urllib.request.Request(
        BASE + path,
        data=json.dumps(payload).encode() if payload is not None else None,
        headers={"X-Api-Key": key, "Content-Type": "application/json"},
        method=method or ("POST" if payload is not None else "GET"))
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("script", nargs="?")
    ap.add_argument("output", nargs="?")
    ap.add_argument("--avatar-id", default=None)
    ap.add_argument("--voice-id", default=None)
    ap.add_argument("--max-cost", type=float, default=2.00)
    ap.add_argument("--list-avatars", action="store_true")
    ap.add_argument("--list-voices", action="store_true")
    args = ap.parse_args()

    key = os.environ.get("HEYGEN_API_KEY")
    if not key:
        sys.exit("HEYGEN_API_KEY not set. Get one at heygen.com -> Settings -> "
                 "Subscriptions & API. Never hardcode it.")

    if args.list_avatars:
        data = api("/v2/avatars", key)
        for a in data.get("data", {}).get("avatars", [])[:40]:
            print(f"{a['avatar_id']:40s} {a.get('avatar_name','')}")
        return
    if args.list_voices:
        data = api("/v2/voices", key)
        for v in data.get("data", {}).get("voices", [])[:40]:
            print(f"{v['voice_id']:40s} {v.get('language','')} {v.get('name','')}")
        return

    if not args.script or not args.output:
        sys.exit("script and output are required (or use --list-avatars/--list-voices)")

    words = len(args.script.split())
    est_min = max(0.25, words / 150)
    est = est_min * 1.00
    if est > args.max_cost:
        sys.exit(f"COST GUARD: ~{est_min:.1f} min of avatar video (~${est:.2f}) "
                 f"exceeds --max-cost ${args.max_cost:.2f}. Raise it explicitly "
                 f"if intended.")
    print(f"Estimated: ~{est_min:.1f} min (~${est:.2f}) — within guard.")

    payload = {
        "video_inputs": [{
            "character": {"type": "avatar",
                          "avatar_id": args.avatar_id or "default",
                          "avatar_style": "normal"},
            "voice": {"type": "text", "input_text": args.script,
                      **({"voice_id": args.voice_id} if args.voice_id else {})},
        }],
        "dimension": {"width": 1280, "height": 720},
    }
    sub = api("/v2/video/generate", key, payload)
    vid = sub.get("data", {}).get("video_id")
    if not vid:
        sys.exit(f"unexpected response: {sub}")

    print("Rendering", end="", flush=True)
    for _ in range(240):
        time.sleep(5)
        st = api(f"/v1/video_status.get?video_id={vid}", key)
        d = st.get("data", {})
        print(".", end="", flush=True)
        if d.get("status") == "completed":
            urllib.request.urlretrieve(d["video_url"], args.output)
            print(f"\nOK {args.output} "
                  f"({os.path.getsize(args.output)//1024} KB)")
            return
        if d.get("status") == "failed":
            sys.exit(f"\nrender failed: {d.get('error')}")
    sys.exit("\ntimed out")


if __name__ == "__main__":
    main()
